import random

def msg(room):
    """Main function to print out a message of which room you end up in once you have chosen a direction.
    
    Parameters
    ----------
    room : string
        The room you end up in.
        
    Returns
    ----------
    answer : string
        The resulting message you are given.
    """
    
    if room['msg'] == '': #There is no custom message
        return "You have entered through the " + room['name'] + '.'
    else:
        return room['msg']
    

def get_choice(room,dir):
    """Gives you the option of which direction you would like to move throughout the house in order to discover
        which room has the Christmas tree and deliver the presents.
        
    Parameters
    ----------
    room : string
        The room you end up in.
    dir : string
        The direction in which you choose to move. 
    
    Returns
    -------
    answer : string
        The result is the room you end up in. 
    """
    
    if dir == 'N':
        choice = 0
    elif dir == 'E':
        choice = 1
    elif dir == 'S':
        choice = 2
    elif dir == 'W':
        choice = 3
    else:
        return -1
    #if room ['directions'] [choice] == 0:
        #return 4
    #else:
    return choice


def run_game():
    """Code help from 'Webucator;Python: Adventure Game' and included with major code modifications/adjustments."""
    
    dirs = (0,0,0,0) #default

    chimney = {'name': 'Chimney', 'directions': dirs, 'msg': ''}
    livingroom = {'name': 'Livingroom', 'directions': dirs, 'msg': ''}
    hallway = {'name': 'Hallway', 'directions': dirs, 'msg': ''}
    kitchen = {'name': 'Kitchen', 'directions': dirs, 'msg': ''}
    diningroom = {'name': 'Diningroom', 'directions': dirs, 'msg': ''}
    bathroom = {'name': 'Bathroom', 'directions': dirs, 'msg': ''}

    #directions are tuples: Rooms to the (N,E,S,W)
    chimney['directions'] = (kitchen, livingroom, 0, 0)
    livingroom['directions'] = (diningroom, 0, 0, chimney)
    hallway['directions'] = (0, kitchen, 0, bathroom) 
    kitchen['directions'] = (0, diningroom, chimney, hallway)
    diningroom['directions'] = (0, 0, livingroom, kitchen)
    bathroom['directions'] = (0, hallway, 0, 0)

    #rooms where the christmas tree might be
    rooms = [livingroom, hallway, kitchen, diningroom, bathroom]
    room_with_presents = random.choice(rooms)
    presents_delivered = False
    room = chimney 
    print('Welcome, Santa! Can you find the Christmas tree?')

    while True:
        if presents_delivered and room['name'] == 'Chimney':
            print('You have delivered the presents and returned to the chimney.' +
                  ' Time to leave now, the reindeer are waiting for you! ' +
                  ' Merry Christmas!')

            break;
        elif not presents_delivered and room['name'] == room_with_presents['name']:
            presents_delivered = True
            print(msg(room) + ' There is the Christmas tree and the child is sleeping ' +
                              'right next to it! You have delivered the presents. ' +
                               'Now hurry and get out!')
            room['msg'] = ('You are back in the ' + room['name'] + 
                          '! You already delivered the presents.' + ' Get out of here before the child wakes up!')
        else:
            print(msg(room))
            room['msg'] = 'You are back in the ' + room['name']

        stuck = True
        while stuck:
            dir = input("Which direction do you want to go: N,E,S,or W?")
            choice = get_choice(room, dir)
            if choice == -1:
                print("Please enter N,E,S, or W?")
            elif choice == 4:
                print("You cannot go in that direction.")
            else:
                room = room['directions'][choice]
                stuck = False
    
    restart = input("Do you wish to play again?").lower()
    if restart == "yes":
        run_game()