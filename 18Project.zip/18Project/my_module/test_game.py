from game import *

#def test_get_choice(room,dir):
 #   assert get_choice(room,dir) == string

def test_get_choice():
    assert get_choice('kitchen', 'N') == 0
    isinstance(get_choice('kitchen', 'N'), int)
    
    
    
#def test_msg(room):
    # assert msg(room) == string